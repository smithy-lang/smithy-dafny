import sys
from typing import Callable, Any, TypeVar, NamedTuple
from math import floor
from itertools import count

import module_
import _dafny
import System_
import Wrappers
import StandardLibrary_mUInt
import StandardLibrary
import UTF8
import simple_types_boolean_internaldafny_types
import SimpleBooleanImpl
import simple_types_boolean_internaldafny_index

assert "module_" == __name__
module_ = sys.modules[__name__]

